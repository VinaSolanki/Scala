package scalaAssignment

import java.io.FileNotFoundException
import scala.collection.mutable.ListBuffer
import scala.io.Source

class FileReading {

  def fileContentReading(fileName: String): ListBuffer[SalaryInfo] = {
    var hikeDetails = new ListBuffer[SalaryInfo]()
    try {
      val fileDetails = Source.fromFile(fileName)
      for (line <- fileDetails.getLines.drop(1)) {
        val row = line.split(",").map(_.trim)
        try {
          hikeDetails += new SalaryInfo(row(0).toInt, row(1).toInt, row(2).toInt, row(3).toInt, row(4).toInt)
          println("hikeDetails"+hikeDetails)
        } catch {
          case e: NumberFormatException => {
            println(e)
          }
          case f: Exception => {
            println(f)
          }
        }
      }
      fileDetails.close()
      } catch {
      case a: FileNotFoundException => {
        throw new FileNotFoundException()
      }
    }
    hikeDetails
  }
}
