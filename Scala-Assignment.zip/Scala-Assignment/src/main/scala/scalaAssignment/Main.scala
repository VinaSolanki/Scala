package scalaAssignment

import java.io.{FileNotFoundException, IOException}
import java.util.Scanner
import scala.collection.mutable.ListBuffer

class Main(var basicSalary: Int, var hra :Int,var lta :Int, var phoneAndInternet : Int, var others:Int ){
    basicSalary =40
    hra=20
    lta=8
    phoneAndInternet=7
    others=25
  }
object Main {

  def main(args: Array[String]) : Unit = {

      val fileName ="../SalaryHikeData.csv"
      println("Reading file")
      val salaryHikeService = new SalaryHikeService()
      var salaryHikeInfo: ListBuffer[SalaryInfo] =salaryHikeService.salaryHikeInfo(fileName)
    println("press 1 for calculating Hike")
      val sc = new Scanner(System.in)
      val option = sc.nextInt()
      option match {
      case 1 => {
        try {
          println("Enter Your Current Salary: ")
          val currentSal =sc.nextInt()
          println("Enter Your Total Experience: ")
          val totalExp = sc.nextInt()
          println("Enter Your HashedIn Experience: ")
          val hashedinExp = sc.nextInt()
          println("Promotion(true/false): ")
          val promotion = readLine()

        } catch {
          case e: Exception =>
            println(e)
        }
      }
      case wrongOption =>
        println("Wrong option selected Please try again !!!!!")
    }
  }
  def calculation(currentSal : Int,totalExp : Int,hashedinExp : Int,promotion :Boolean ,salaryHikeInfo : ListBuffer[SalaryInfo]): Unit ={
    val totalExpwithhike = 5
    val totalExpwithhashedinhike = 5
    val promotionHike = 10
    for (list <- salaryHikeInfo) {
      if (list == totalExp) {

        budgetMovie += movie
        noOutputFlag = false
      }
    }
    val hikeProposal = currentSal * (totalExpwithhike/100 + totalExpwithhashedinhike/100 + promotionHike/100)


    val incrementSal = println("Total" +hikeProposal)
    val basicSal = println(hikeProposal * /100 )

      Total = 440000
    Basic salary : 440000* (40/100)
    HRA : 440000 * (20/100)
    LTA: 440000 * (8/100)
    Phone and internet: 440000 * (7*100)
    Other: 440000 * (25/100)

  }

}
