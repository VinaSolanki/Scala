package scalaAssignment

import java.beans.BeanProperty

class SalaryInfo(@BeanProperty totalExp: Int,
                 @BeanProperty hashedinExp : Int,
                 @BeanProperty normalHike : Int ,
                 @BeanProperty hashedinHike: Int ,
                 @BeanProperty promotionBonus : Int){

}
