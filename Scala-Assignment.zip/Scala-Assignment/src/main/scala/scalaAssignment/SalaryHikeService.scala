package scalaAssignment

import scala.collection.mutable.ListBuffer

class SalaryHikeService {

  private var salaryHikeInfo: ListBuffer[SalaryInfo] = new ListBuffer[SalaryInfo]()

  def salaryHikeInfo(fileName : String): ListBuffer[SalaryInfo]  ={
      val fileReader= new FileReading()
      salaryHikeInfo = fileReader.fileContentReading(fileName)
    salaryHikeInfo
  }
}
